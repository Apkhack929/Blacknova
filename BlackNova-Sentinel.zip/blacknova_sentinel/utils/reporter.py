import json
import os
from datetime import datetime

def save_report(target, results):
    if not os.path.exists("output"):
        os.makedirs("output")
    filename = f"output/report_{target.replace('.', '_')}.json"
    report = {
        "target": target,
        "results": results,
        "timestamp": str(datetime.now())
    }
    with open(filename, "w") as f:
        json.dump(report, f, indent=4)
    print(f"[+] Report saved to {filename}")
