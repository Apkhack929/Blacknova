import requests

def check_headers(target):
    try:
        response = requests.get(f"http://{target}", timeout=3)
        headers = response.headers
        security_headers = [
            "Content-Security-Policy",
            "X-Frame-Options",
            "X-Content-Type-Options",
            "Strict-Transport-Security"
        ]
        missing = []
        for header in security_headers:
            if header not in headers:
                missing.append(header)
        return {"missing_security_headers": missing}
    except:
        return {"error": "Could not fetch HTTP headers"}
