def check_authorization():
    confirm = input("Do you confirm you have authorization? (yes/no): ").lower()
    return confirm == "yes"
