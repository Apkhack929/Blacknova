import socket
import threading
from queue import Queue

timeout = 1
threads_count = 50

def worker(target, q, results):
    while not q.empty():
        port = q.get()
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            if s.connect_ex((target, port)) == 0:
                banner = ""
                try:
                    s.send(b"HEAD / HTTP/1.0\r\n\r\n")
                    banner = s.recv(1024).decode(errors="ignore").strip()
                except:
                    pass
                print(f"[+] Port {port} OPEN")
                results.append({"port": port, "banner": banner})
            s.close()
        except:
            pass
        q.task_done()

def run_scan(target, start_port, end_port):
    q = Queue()
    results = []
    for port in range(start_port, end_port + 1):
        q.put(port)
    threads = []
    for _ in range(threads_count):
        t = threading.Thread(target=worker, args=(target, q, results))
        t.start()
        threads.append(t)
    q.join()
    return results
