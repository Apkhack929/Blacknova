from core.authorization import check_authorization
from core.scanner import run_scan
from core.http_checker import check_headers
from utils.reporter import save_report

def main():
    if not check_authorization():
        print("Authorization required. Exiting.")
        return

    target = input("Target (IP or Domain): ").strip()
    start_port = int(input("Start Port: "))
    end_port = int(input("End Port: "))

    print("\n[+] Scanning ports...")
    scan_results = run_scan(target, start_port, end_port)

    print("\n[+] Checking HTTP headers...")
    header_results = check_headers(target)

    final_results = {
        "ports": scan_results,
        "http_analysis": header_results
    }

    save_report(target, final_results)
    print("\n[+] Scan completed successfully!")

if __name__ == "__main__":
    main()
